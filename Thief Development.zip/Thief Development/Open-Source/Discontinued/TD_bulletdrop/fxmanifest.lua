fx_version 'cerulean'
game 'gta5'

author 'Thief | GamingThief'
description 'Static BulletDrop In FiveM'
version '1.0'

client_script {
    'data/client.lua'
}
