fx_version 'cerulean'
game 'gta5'

author 'Thief | GamingThief'
description 'Headlight Damage'
version '1.0.0'
lua54 'yes'

server_script 'data/server.lua'

client_scripts {
    'data/client.lua',
    'config.lua'
}

shared_scripts{
    'config.lua'
}
