
Hello, this is Thief from Thief Development and XotiicStore! I’m so glad that you’ve chosen Thief Development for your script(s) on your server.
My team and I know how important it is to avoid overpaying or being locked into just one developer. If you’re reading this,
it’s because you’ve seen what we can bring to the table! We created this script because we, along with XotiicStore,
understand the importance of having full modularity and compatibility for your server and its scripts. If you run into any issues whether it’s a bug,
an odd error, or if you simply have a question about the backend escrowed code—feel free to join our Discord through this readme or via the Tebex store. 
Open a ticket, and we’ll be happy to assist you with the bug, error, or any questions you have. Now, I’ll stop taking up your time. Enjoy the script(s)!"

Signed,
Thief/GamingThief
Thief Development Founder & Owner | XotiicStore Co-Owner

Tebex Store: https://thief-development.tebex.io/
Discord: https://discord.gg/NF9S274jKr (XotiicStore)
Documentation: Coming Soon!