-- Config.lua

Config = {}

-- Permission group for the setweather command
Config.WeatherCommandPermission = "command.setweather"
