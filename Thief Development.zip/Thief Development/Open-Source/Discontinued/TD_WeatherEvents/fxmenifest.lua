fx_version 'cerulean'
game 'gta5'

author 'GamingThief | Thief Development'
description 'Weather Events Using BASE GTA Weathers'
version '1.0.0'

client_scripts {
    'config.lua',
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}
