fx_version 'cerulean'
game 'gta5'

author 'GamingThief | Thief Development'
description 'WIP'
version '1.0.0'

server_scripts {
    'server/server.lua'
}

client_scripts {
    'client/client.lua'
}
