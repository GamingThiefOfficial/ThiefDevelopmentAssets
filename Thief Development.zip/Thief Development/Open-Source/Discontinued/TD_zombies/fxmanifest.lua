fx_version 'cerulean'
game 'gta5'

author 'GamingThief'
description 'Standalone Zombie Spawner'
version '1.0.0'

client_script 'client/client.lua'
