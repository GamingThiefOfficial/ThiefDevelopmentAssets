Hello, If your reading this, WQW but thank you! 

Thief Development was ONE HELL of a ride, first it started as a Standalone default server fixing scripts to a Standlone Game Supporting scripts and now going to slight ECO scripts and then partering with XotiicStore was amazing. 

We closed down today (IF you are reading this later its currently, June 5th, 2025 @ 6:00pm EST).
Any and ALL scripts in here are provided AS IS and MOST scripts are BROKEN/NOT FINISHED and NO SUPPORT will be given (If you have any questions I MAY provide some help) but who knows discord is GamingThief  // Thief  ) 

Thief Development is not around anymore, and is not part of my new adventure with DHS. Enjoy. 

(If anyone finishes these i would love some base code credit but isn't required. and if it does get completed please do content id love to see it. 

Farewell for now. 

- GamingThief || Thief
- Former Founder/Owner TD // Thief Development  / XotiicStore Co-owner